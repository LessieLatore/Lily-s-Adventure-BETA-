#include <iostream>
#include "C:/Users/Lessiee/scoop/apps/raylib/5.5/raylib-5.5_win64_msvc16/include/raylib.h"
#include <vector>
#include <string>


// Definição da estrutura Enemy
struct Enemy {
    float x, y; // Posição
    float speed; // Velocidade
    int frame; // Quadro de animação
    float timer; // Temporizador de animação
    float frameTime; // Tempo de cada quadro
    bool isAlive; // Status de vida

    // Construtor do inimigo
    Enemy(float startX, float startY, float startSpeed) 
        : x(startX), y(startY), speed(startSpeed), frame(0), timer(0.0f), frameTime(0.2f), isAlive(true) {}
};

// Função para gerar uma posição aleatória para o inimigo
float GenerateRandomSpawnPosition(bool& isSpawnLeft) {
    // Randomiza a posição de spawn do inimigo
    isSpawnLeft = (GetRandomValue(0, 1) == 0); // Determina se o inimigo vai nascer à esquerda ou direita
    return isSpawnLeft ? -1000.0f : 1000.0f; // Posições à esquerda ou à direita da tela
}

int main()
{
    // Inicializa a janela
    InitWindow(1024, 900, "Lily's Adventure");
    SetTargetFPS(60);

    // Carrega as texturas de fundo
    Texture2D backgroundMenu = LoadTexture("Menu.png");
    if (backgroundMenu.id == 0) {
        std::cerr << "Erro ao carregar a imagem Menu.png" << std::endl;
        return 1;
    }

    Texture2D backgroundBattle = LoadTexture("Background.png");
    if (backgroundBattle.id == 0) {
        std::cerr << "Erro ao carregar a imagem Background.png" << std::endl;
        return 1;
    }

    Texture2D characterSprite = LoadTexture("sprites.png");
    if (characterSprite.id == 0) {
        std::cerr << "Erro ao carregar a imagem sprites.png" << std::endl;
        return 1;
    }

    // Carrega a textura do inimigo
    Texture2D inimigoSprite = LoadTexture("inimigos.png");
    if (inimigoSprite.id == 0) {
        std::cerr << "Erro ao carregar a imagem enemySprite.png" << std::endl;
        return 1;
    }

    // Variáveis de controle de menu e jogo
    bool inMenu = true;
    bool gamestarted = false;
    bool showBattleMessage = true;
    //variaveis de registro do nome
    std::string playerName = "";  // Nome do jogador
    //time
    float gameTime = 0.0f; // Tempo decorrido em segundos
    

    // Variáveis para a contagem regressiva
    float countdownTimer = 0.0f;  // Temporizador de contagem regressiva
    int countdownValue = 3;       // Valor da contagem regressiva (começa em 3)

    // Variáveis de animação da Lily
    const int frameWidth = 500;  // Largura de cada quadro da animação (sprite)
    const int frameHeight = 510; // Altura de cada quadro da animação
    int currentFrame = 0;        // Quadro atual da animação
    int currentRow = 0;          // Linha atual da animação (0 para esquerda, 1 para direita, 2 para ataque)
    float frameTime = 0.2f;      // Tempo de duração de cada quadro
    float jumpFrameTime = 1.f;   // Tempo de duração de cada quadro enquanto o personagem está pulando
    float timer = 0.0f;          // Temporizador para controle de troca de quadros
    float jumpTimer = 0.0f;      // Temporizador para animação de pulo

    // Posição inicial do personagem
    float characterX = 350.0f;
    float characterY = 350.0f;
    float characterSpeed = 10.0f;  // Velocidade do personagem

    // Variáveis para saber se o personagem está em movimento, controle do pulo e ataque
    bool isMoving = false;
    bool isJumping = false;
    bool isAttacking = false;     // Nova variável para verificar se o personagem está atacando
    float velocityY = 0.0f;
    const float jumpSpeed = -15.0f; // Velocidade do pulo (valor negativo para subir)
    const float gravity = 0.5f;     // Gravidade que puxa o personagem para baixo
    const float groundLevel = 350.0f; // Nível do chão (posição no eixo Y)

    // Variável para controlar a direção que a personagem está enfrentando
    bool facingLeft = false;

    // Lista de inimigos
    std::vector<Enemy> enemies;

    // Lógica de respawn do inimigo
    float respawnTimer = 0.0f;  // Temporizador para respawn
    const float respawnDelay = 3.0f;  // Delay de 3 segundos para respawn

    // Adicionando o score
    int score = 0;  // Variável para o score do jogo

    // Loop principal
    while (!WindowShouldClose())
    {   gameTime += GetFrameTime(); // Incrementa o tempo decorrido
        
        
        // Manipulação de eventos
        if (IsKeyPressed(KEY_ENTER) && inMenu)
        {
            inMenu = false;
            gamestarted = true;
            showBattleMessage = true;
        }
        if (IsKeyPressed(KEY_ESCAPE))
        {
            CloseWindow();
            return 0;
        }  
        if (score >= 5000){
            inMenu = true;
            gamestarted = false;
            playerName += " _ " + std::to_string(score);
            score = 0;
        }
         

        // Caso o jogo tenha começado, aguardamos a contagem regressiva
        if (gamestarted && countdownValue > 0)
        {    
            countdownTimer += GetFrameTime();
          
            // Se o temporizador de contagem regressiva atingir 1 segundo, decrementa o valor
            if (countdownTimer >= 1.0f)
            {
                countdownTimer = 0.0f;  // Reseta o temporizador
                countdownValue--;       // Decrementa o valor da contagem regressiva
            }
        }

        // Movimentação do personagem com as setas do teclado
        if (IsKeyDown(KEY_RIGHT))
        {
            characterX += characterSpeed;  // Move para a direita
            facingLeft = false;
            isMoving = true;
        }
        else if (IsKeyDown(KEY_LEFT))  
        {
            characterX -= characterSpeed;  // Move para a esquerda
            facingLeft = true;
            isMoving = true;
        }
        else
        {
            isMoving = false;  // A personagem não está se movendo
        }

        // Controle do pulo
        if (IsKeyPressed(KEY_SPACE) && !isJumping && !isAttacking)  // Verifica se não está atacando ou já pulando
        {
            // Inicia o pulo
            isJumping = true;
            velocityY = jumpSpeed;  // A velocidade de pulo (valor negativo para subir)
            currentRow = 1;  // Muda para a linha 1 do sprite para animação de pulo
            currentFrame = 0; // Inicia a animação de pulo no quadro 0
        }

        // Controle do ataque
        if (IsKeyPressed(KEY_F) && !isAttacking && !isJumping)  // Impede o ataque enquanto está se movendo ou pulando
        {
            // Inicia o ataque
            isAttacking = true;
            currentRow = 2;  // Muda para a linha 2 do sprite para animação de ataque
            currentFrame = 0; // Inicia a animação de ataque no quadro 0
        }

        // Atualização do pulo
        if (isJumping)
        {
            characterY += velocityY;  // Atualiza a posição vertical

            // Aplica a gravidade
            velocityY += gravity;

            // Verifica se a personagem chegou no chão
            if (characterY >= groundLevel)
            {
                characterY = groundLevel;  // Coloca no chão
                isJumping = false;         // Fim do pulo
                currentRow = 0;            // Volta para a linha 0 quando no chão
            }
        }

        // Lógica de animação durante o pulo (continua a animação até o personagem tocar o chão)
        if (isJumping)
        {
            jumpTimer += GetFrameTime();
            if (jumpTimer >= jumpFrameTime)
            {
                currentFrame++;  // Avança para o próximo quadro
                if (currentFrame >= 3)  // Se atingiu o terceiro quadro, fixa no terceiro
                {
                    currentFrame = 2;  // Fixa no quadro 2 (último quadro do pulo)
                }
                jumpTimer = 0.0f;  // Reseta o temporizador de animação do pulo
            }
        }
        else if (isAttacking)
        {
            // Lógica de animação do ataque
            timer += GetFrameTime();
            if (timer >= frameTime)
            {
                currentFrame++;  // Avança para o próximo quadro
                if (currentFrame >= 3)  // Se atingiu o último quadro de ataque
                {
                    currentFrame = 0;  // Reseta para o primeiro quadro
                    isAttacking = false;  // Finaliza o ataque
                    currentRow = 0;       // Volta para a animação normal de movimento
                }
                timer = 0.0f;  // Reseta o temporizador de animação
            }

            // Ajusta a área de ataque dependendo da direção (esquerda ou direita)
            Rectangle attackArea;
            
            if (facingLeft) {
                // Quando o personagem está virado para a esquerda
                attackArea = { 
                    characterX - 200,  // Posição inicial do ataque à esquerda do personagem
                    characterY, 
                    200,  // Largura negativa para o ataque ir para a esquerda
                    frameHeight 
                };
            } else {
                // Quando o personagem está virado para a direita
                attackArea = { 
                    characterX + 200,  // Posição inicial do ataque à direita do personagem
                    characterY, 
                    200,  // Largura positiva para o ataque ir para a direita
                    frameHeight 
                };
            }

            // Lógica de ataque - Verifica a colisão com os inimigos
for (auto& enemy : enemies) {
    // Só verifica a colisão com inimigos vivos
    if (!enemy.isAlive) continue;  // Ignora inimigos mortos ou invisíveis

    // Cria a área de ataque
    Rectangle attackArea;
    if (facingLeft) {
        // Quando o personagem está virado para a esquerda
        attackArea = { 
            characterX - 200,  // Posição inicial do ataque à esquerda do personagem
            characterY, 
            -200,  // Largura negativa para o ataque ir para a esquerda
            frameHeight 
        };
    } else {
        // Quando o personagem está virado para a direita
        attackArea = { 
            characterX + 200,  // Posição inicial do ataque à direita do personagem
            characterY, 
            200,  // Largura positiva para o ataque ir para a direita
            frameHeight 
        };
    }

         // Certifique-se de que a área de ataque está dentro da tela
         if (attackArea.x + attackArea.width < 0 || attackArea.x > GetScreenWidth()) {
            continue;  // Se a área de ataque está fora da tela, não checa colisões
         }

        // Verifica se a área de ataque colide com o inimigo
         if (CheckCollisionRecs(attackArea, { enemy.x, enemy.y, 150.0f, 150.0f })) {
                 // O inimigo foi atingido, "destrua-o"
                 enemy.isAlive = false; // Marca o inimigo como morto
                 score += 1000;  // Adiciona 10 pontos ao score
                }
            }
        }
        else if (isMoving)
        {
            // Atualiza a animação de movimento (com 3 quadros) somente quando não estiver pulando
            if (!isJumping)  // Se não estiver pulando, anima o movimento
            {
                timer += GetFrameTime();
                if (timer >= frameTime)
                {
                    currentFrame++;  // Avança para o próximo quadro
                    if (currentFrame >= 3)  // Se atingiu o terceiro quadro, volta para o primeiro
                    {
                        currentFrame = 0;
                    }
                    timer = 0.0f;  // Reseta o temporizador
                }
            }
        }
        else
        {
            currentFrame = 0;  // Caso não esteja fazendo nada (reposo)
        }

        // Lógica de movimento dos inimigos
        for (auto& enemy : enemies) {
            if (!enemy.isAlive) continue;  // Se o inimigo foi derrotado, ignora sua movimentação

            if (enemy.x >= 1200.0f || enemy.x <= 0.0f) enemy.speed = -enemy.speed;  // Faz o inimigo voltar na tela
            enemy.x += enemy.speed;  // Atualiza a posição do inimigo

            // Lógica de animação do inimigo
            enemy.timer += GetFrameTime();
            if (enemy.timer >= enemy.frameTime) {
                enemy.frame++;
                if (enemy.frame >= 3) {
                    enemy.frame = 0;
                }
                enemy.timer = 0.0f;
            }
        }

        // Lógica de respawn dos inimigos
        respawnTimer += GetFrameTime();
        if (respawnTimer >= respawnDelay)  // Após o tempo de respawn
        {
            bool isSpawnLeft;
            enemies.push_back(Enemy(GenerateRandomSpawnPosition(isSpawnLeft), 700.0f, 5.0f));
            respawnTimer = 0.0f;  // Reseta o temporizador de respawn
        }

        // Desenho
        BeginDrawing();
        ClearBackground(RAYWHITE);

        if (inMenu)
        {
            DrawTexture(backgroundMenu, 0, 0, WHITE);
            DrawText("Pressione ENTER para Começar", 50, 600, 30, PINK);
            if (playerName != "") {
                DrawText(("Name: " + playerName).c_str(), 50, 450, 30, PINK);
            }
            DrawText("Pressione ESC para Sair", 50, 650, 30, PINK);
       
            //campo para digitar o nome
            DrawText("Digite seu nome: ", 50, 500, 30, PINK);
            DrawText(playerName.c_str(), 50, 550, 30, PINK);
            
            //Capturar o nome
            if (IsKeyPressed(KEY_BACKSPACE) && playerName.length() > 0)
            {
                playerName.pop_back();
            }

            //adicionar novas letras ao nome
            for (int key = KEY_A; key <= KEY_Z; key++)
            {
                if (IsKeyPressed(key))
                playerName += (char)(key);
            }
        }
        else if (gamestarted && countdownValue > 0)
        {
            // Exibe a contagem regressiva
            DrawText(TextFormat("Começa em %d...", countdownValue), 400, 300, 30, PINK);
        }
        else if (gamestarted)
        {       
            if (showBattleMessage)
            {   
                DrawText("Começe a Batalha!", 300, 300, 30, PINK);
                if (GetTime() > 8.0f)
                {
                    showBattleMessage = false;
                }
            }
            else
            {   
                DrawTexture(backgroundBattle, 0, 0, WHITE);
                DrawText(TextFormat("Tempo: %.2f", gameTime), 10, 50, 30, PINK);

                // Calculando a área da fonte (sourceRec) para o quadro atual da Lily
                Rectangle sourceRec;
                if (facingLeft)
                {
                    sourceRec.x = (float)((currentFrame + 1) * frameWidth);
                    sourceRec.y = (float)(currentRow * frameHeight);
                    sourceRec.width = (float)-frameWidth;
                    sourceRec.height = (float)frameHeight;
                }
                else
                {
                    sourceRec.x = (float)(currentFrame * frameWidth);
                    sourceRec.y = (float)(currentRow * frameHeight);
                    sourceRec.width = (float)frameWidth;
                    sourceRec.height = (float)frameHeight;
                }
                
                Rectangle destRec = { characterX, characterY, (float)frameWidth, (float)frameHeight };

                DrawTexturePro(characterSprite, sourceRec, destRec, Vector2{ 0, 0 }, 0.0f, WHITE);

                
                // Desenha todos os inimigos
                for (const auto& enemy : enemies)
                {
                    if (enemy.isAlive)
                    {
                        Rectangle enemySourceRec = {
                            (float)(enemy.frame * 32),
                            0.0f,
                            32.0f,
                            32.0f
                        };
              
                        Rectangle enemyDestRec = { enemy.x, enemy.y, 150.0f, 150.0f };

                        DrawTexturePro(inimigoSprite, enemySourceRec, enemyDestRec, Vector2{ 0, 0 }, 0.0f, WHITE);
                    }
                }
                
                // Exibe o score na tela
                DrawText(TextFormat("Score: %d", score), 10, 10, 30, PINK);
            }
        }

        EndDrawing();
    }

    // Finaliza a janela
    CloseWindow();
    return 0;
}
